package StudentServlet;

import java.io.IOException;
import java.sql.SQLException;

import StudentEntity.StudentPojo;
import dao.StudentDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/getStudentDetailsById")
public class GetStudentDetailsServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * Default constructor. 
     */
	
	private StudentDao dao;

    public void init() {
    	try {
			dao = new StudentDao();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
    String studentId = request.getParameter("id");
    StudentPojo studentDetails = new StudentPojo();
   
    try {
    	studentDetails = dao.getStudentDetailsbyId(Integer.parseInt(studentId));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	request.setAttribute("studentDetails", studentDetails);
    request.getRequestDispatcher("StudentDetails.jsp").forward(request, response);
   
   }
}
