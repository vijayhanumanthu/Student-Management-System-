package StudentServlet;

import java.io.IOException;
import java.sql.SQLException;

import StudentEntity.StudentPojo;
import dao.StudentDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/studentform")
public class StudentDetailsServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private StudentDao dao;

    public void init() {
    	try {
			dao = new StudentDao();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	String id = request.getParameter("id");
        String studentname = request.getParameter("studentname");
        String studentclass = request.getParameter("studentclass");
        String section = request.getParameter("section");
        String bloodtype = request.getParameter("bloodtype");
        

        StudentPojo studentDetails = new StudentPojo();
        studentDetails.setStudentId(Integer.parseInt(id));
        studentDetails.setStudentName(studentname);
        studentDetails.setStudentClass(studentclass);
        studentDetails.setStudentSection(section);
        studentDetails.setStudentBloodGroup(bloodtype);
        try {
        	dao.addStudentDetails(studentDetails);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        response.sendRedirect("getStudentDetailsById.jsp");
    }

}
