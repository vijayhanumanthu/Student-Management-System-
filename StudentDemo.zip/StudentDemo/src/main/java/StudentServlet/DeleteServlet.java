package StudentServlet;

import java.io.IOException;
import java.sql.SQLException;

import dao.StudentDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Delete")
public class DeleteServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private StudentDao dao;

    public void init() {
    	try {
			dao = new StudentDao();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
    String studentId = request.getParameter("id");
   
    try {
     dao.deleteStudentDetails(Integer.parseInt(studentId));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    response.getWriter().print("Record Deleted");
   }

}
